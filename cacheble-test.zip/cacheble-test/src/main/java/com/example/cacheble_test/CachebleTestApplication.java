package com.example.cacheble_test;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CachebleTestApplication {

	public static void main(String[] args) {
		SpringApplication.run(CachebleTestApplication.class, args);
	}

}
